
flush ruleset

table inet filter {
    chain input {
        type filter hook input priority filter; policy drop;

        # ????????? ??? ????????????? ? ?????????? ??????????

        ct state established,related accept

        # ????????? ????????? ????? (loopback) ??? ?????????? ?????

        iif "lo" accept

        # ????????? ???? (ICMP)

        ip protocol icmp accept
        ip6 nexthdr icmpv6 accept

        # ??????? ????? SSH (22) ? VNC (5900)

        tcp dport 22 accept
        tcp dport 5900 accept
    }

    chain forward {
        type filter hook forward priority filter; policy accept;
    }

    chain output {
        type filter hook output priority filter; policy accept;
    }
}
EOF

sudo systemctl enable --now nftables
apt install git
git config --global user.name "Sergey Maksimov"
git config --global user.email "m6v@mail.ru"
mc
rm ~/.bash_history 
apt install docker.io
apt install docker-compose
mc
grep -? ?????????????? ???????????;
grep -oP "pam_cracklib\.so's+K.*" /etc/pam.d/common-password 
cat /etc/pam.d/common-password
grep -oP "pam_cracklib\.so\s+\K.*" /etc/pam.d/common-password 
cat /proc/self/mounts
grep ext4 /proc/self/mounts
ещз
top
ping 8.8.8.8
ping ya.ru
./vlab
mkdir -p /etc/docker
cat << EOF > /etc/docker/daemon.json
{ "astra-sec-level": 6 }
EOF

systemctl restart docker
df -h
mc
mount -t iso9660 extended-1.7.6.EXT2.1-15.10.2024_20.28.iso /srv/repo/alse/extended
mount -t iso9660 base-1.7.6.15-15.11.24_17.20.iso /srv/repo/alse/base
find / -name *novnc*
apt install ./novnc_1.0.0-1_all.deb 
apt install ./python-novnc_1.0.0-1_all.deb 
find . -name python-oslo*
find . -name *python-oslo*
apt search python-oslo
apt search python-oslo-config
apt install ./python-oslo.config_6.4.1-1_all.deb 
apt install ./python-debtcollector_1.20.0-2_all.deb 
apt install ./python-wrapt_1.10.11-1+b1_amd64.deb 
ls .
apt install ./python-debtcollector_1.20.0-2_all.deb 
ls
apt install python-oslo.config_6.4.1-1_all.deb 
apt install ./python-oslo.config_6.4.1-1_all.deb 
apt install ./python-docutils_0.14+dfsg-4_all.deb 
apt install ./python-roman_2.0.0-3_all.deb 
ls
apt install ./python-docutils_0.14+dfsg-4_all.deb 
apt install ./python-oslo.config_6.4.1-1_all.deb 
apt install ./python-oslo.i18n_3.21.0-2_all.deb 
apt install ./python-babel_2.6.0+dfsg.1-1+deb10u1_all.deb 
apt install ./python-oslo.i18n_3.21.0-2_all.deb 
apt install ./python-oslo.config_6.4.1-1_all.deb 
apt install ./python-rfc3986_0.3.1-2_all.deb 
apt install ./python-oslo.config_6.4.1-1_all.deb 
find . -name python-stevedore
find . -name *python-stevedore*
apt install ./python-stevedore_1.29.0-2_all.deb 
apt install ./python-oslo.config_6.4.1-1_all.deb 
find /srv/repo -name *python-yaml*
apt install ./python-yaml_5.1.2-1+b1_amd64.deb 
apt install ./python-oslo.config_6.4.1-1_all.deb 
apt install ./novnc_1.0.0-1_all.deb 
apt install ./python-novnc_1.0.0-1_all.deb 
find /srv/repo -name *websok*
apt install ./novnc_1.0.0-1_all.deb 
find /srv/repo -name *websockify*
apt install ./websockify_0.8.0+dfsg1-10_amd64.deb 
apt install ./python3-websockify_0.8.0+dfsg1-10_amd64.deb 
apt install ./websockify-common_0.8.0+dfsg1-10_all.deb 
apt install ./python3-websockify_0.8.0+dfsg1-10_amd64.deb 
find /srv/repo -name *python3-numpy*
apt install ./python3-numpy_1.16.2-1+b1_amd64.deb 
apt install ./python3-websockify_0.8.0+dfsg1-10_amd64.deb 
apt install ./novnc_1.0.0-1_all.deb 
apt install ./websockify_0.8.0+dfsg1-10_amd64.deb 
apt install ./novnc_1.0.0-1_all.deb 
umount base 
umount extended 
apt install ansible
cat << EOF > /etc/systemd/system/vlab-panel.service
[Unit]
Description=noVNC Central Token Server for Classroom
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/websockify --web /usr/share/novnc 8080 --target-config=/etc/novnc/tokens
Restart=always
User=root

[Unit]
[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now novnc-instructor
mkdir /etc/novnc
cp tokens.json /etc/novnc
systemctl enable --now vlab-panel
systemctl status --now vlab-panel
./server.py 
./server.py
cp vlab-panel.service /etc/systemd/system
systemctl daemon-reload
systemctl restart vlab-panel.service
systemctl status vlab-panel.service
systemctl stop vlab-panel.service
systemctl disable vlab-panel.service
mv vlab-panel.service websockify.service
cp websockify.service vlab-panel.service
mv websockify.service websockify.service.bak
systemctl daemon-reload
systemctl start vlab-panel.service
systemctl status vlab-panel.service
systemctl enable vlab-panel.service
mc
systemctl status vlab-panel
ip a
systemctl status vlab-panel
systemctl restart vlab-panel
systemctl disable vlab-panel
ps ax | grep web
kill 1320
ps ax | grep web
kill 1320
ps ax | grep web
mc
./server.py
cat /etc/systemd/system/vlab-panel.service 
mc
cp /etc/X11/xorg.conf /etc/X11/xorg.conf.bak
cat << 'EOF' > /etc/X11/xorg.conf
Section "Screen"
    Identifier     "Default Screen"
    SubSection     "Display"
        Virtual    1920 1080
    EndSubSection
EndSection
EOF

systemctl restart fly-dm
nano /srv/vlab-panel/server.py 
mcedit /srv/vlab-panel/server.py 
mcedit /srv/vlab-panel/server.py 
mcedit /srv/vlab-panel/server.py 
mcedit /srv/vlab-panel/server.py 
mcedit /srv/vlab-panel/server.py 
mcedit /srv/vlab-panel/server.py 
mcedit /srv/vlab-panel/server.py 
cat /srv/vlab-panel/server.py 
mcedit /srv/vlab-panel/server.py 
cp /srv/vlab-panel/server.py /srv/vlab-panel/server.py.bak
mcedit /srv/vlab-panel/server.py 
./server.py
systemctl enable --now vlab-panel.service 
systemctl stop vlab-panel.service 
systemctl status vlab-panel.service 
ps ax | grep python
ps ax | grep web
systemctl start vlab-panel.service 
./server.py
ps ax | server
ps ax | grep server
kill 6217
ps ax | grep server
./server.py
ps ax | grep server
./server.py
systemctl enable --now vlab-panel
systemctl restart vlab-panel
ps ax | grep server.ry
ps ax | grep status vlab-panel
systemctl status vlab-panel
systemctl restart vlab-panel
systemctl status vlab-panel
systemctl restart vlab-panel
systemctl stop vlab-panel
./server.py
systemctl start vlab-panel
systemctl restart vlab-panel
systemctl statгы vlab-panel
systemctl status vlab-panel
./server.py
ps ax | grep web
./server.py
ss -tulpan | grep 8000
./server.py
systemctl restart vlab-panel
ps ax | grep python
mc
ps ax
id
ls /
ip a
apt update
apt install geany
apt update
apt install geany
apt update
ip a
mount -t overlay overlay -o lowerdir=/,upperdir=/var/lib/machines/timemachine/upper,workdir=/var/lib/machines/timemachine/work /var/lib/machines/timemachine/merged
systemd-nspawn -M timemachine --keep-unit --register=no -D /var/lib/machines/timemachine/merged /usr/bin/sleep infitiny
systemd-nspawn -M timemachine --keep-unit --register=no -D /var/lib/machines/timemachine/merged /usr/bin/sleep infitity
systemd-nspawn -M timemachine --keep-unit --register=no -D /var/lib/machines/timemachine/merged /usr/bin/sleep infinity
systemd-nspawn -M timemachine --keep-unit -D /var/lib/machines/timemachine/merged /usr/bin/sleep infinity
systemd-nspawn -M timemachine -D /var/lib/machines/timemachine/merged /usr/bin/sleep infinity
make restart
du -h arm-o.qcow2 
du -h
df -h
lsusb
./Квартплата-2022-12.txt
./vlab.sh
systemctl daemon-reload
systemctl restart timemachine
systemctl status timemachine
ss -tulpan
nsenter --target $(machinectl show timemachine -p Leader --value) --mount --uts --ipc --pid /bin/sh
systemctl daemon-reload
systemctl status timemachine
systemctl restart timemachine
systemctl status timemachine
ss -tulpan
ss -tulpan | grep 123
ps ax | grep chrony
ps aux
ps aux | chrony
ps aux | grep chrony
systemctl stop timemachine
ps aux | grep chrony
systemctl start timemachine
ps aux | grep chrony
machinectl show timemachine -p Leader --value
machinectl list
systemd-cgls -M timemachine
systemd-cgls
systemd-cgls -M timemachine
sudo systemd-cgls | grep chrony
sudo systemd-cgls
sudo systemd-cgls | grep chrony
sudo systemd-cgls
systemctl restart timemachine
systemctl status timemachine
ss -tulpan | grep 123
systemd-nspawn -D /var/lib/machines/timemachine/merged /bin/sh
systemctl daemon-reload
systemctl start timemachine
systemctl status timemachine
systemctl stop timemachine
systemctl daemon-reload
systemctl status timemachine
systemctl start timemachine
systemctl status timemachine
systemctl stop timemachine
systemctl start timemachine
systemctl status timemachine
systemctl stop timemachine
systemctl start timemachine
systemctl status timemachine
systemctl stop timemachine
systemctl daemon-reload
systemctl start timemachine
systemctl status timemachine
ss -tulpan | grep 123
systemctl stop timemachine
systemctl start timemachine
systemctl status timemachine
ss -tulpan | grep 123
systemctl status timemachine
machinectl list
ps ax | grep chrony
systemctl stop timemachine
systemctl start timemachine
machinectl list
nsenter --target $(machinectl show timemachine -p Leader --value) --mount --uts --ipc --pid /bin/sh
systemctl stop timemachine
systemctl start timemachine
systemctl status timemachine
sudo ss -ulnp | grep :123
journalctl -u timemachine.service -n 50 --no-pager
nsenter --target $(machinectl show timemachine -p Leader --value) --mount --uts --ipc --pid /bin/sh
systemctl stop timemachine
systemctl daemon-reload
systemctl start timemachine
systemctl status timemachine
machinectl list
systemctl stop timemachine
systemctl daemon-reload
systemctl start timemachine
systemctl status timemachine
machinectl list
nsenter --target $(machinectl show timemachine -p Leader --value) --mount --uts --ipc --pid /bin/sh
systemctl stop timemachine
systemctl start timemachine
systemctl stop timemachine
systemctl start timemachine
systemctl stop timemachine
systemctl start timemachine
systemctl status timemachine
nsenter --target $(machinectl show timemachine -p Leader --value) --mount --uts --ipc --pid /bin/sh
systemctl stop timemachine
systemctl start timemachine
nsenter --target $(machinectl show timemachine -p Leader --value) --mount --uts --ipc --pid /bin/sh
systemctl status timemachine
systemctl stop timemachine
systemctl start timemachine
systemctl stop timemachine
systemctl start timemachine
systemctl stop timemachine
systemctl start timemachine
nsenter --target $(machinectl show timemachine -p Leader --value) --mount --uts --ipc --pid /bin/sh
nsenter --target $(machinectl show timemachine -p Leader --value) --mount --net --uts --ipc --pid /bin/sh
systemctl stop timemachine
mount
umount /var/lib/machines/timemachine/merged
systemctl status timemachine
systemctl start timemachine
systemctl status timemachine
systemctl stop timemachine
systemctl status timemachine
systemctl stop timemachine
systemctl start timemachine
systemctl status timemachine
machinectl list
nsenter --target $(machinectl show timemachine -p Leader --value) --mount --uts --ipc --pid /bin/sh
nsenter --target $(machinectl show timemachine -p Leader --value) --mount --net --uts --ipc --pid /bin/sh
machinectl list
systemctl status timemachine
mount
umount /var/lib/machines/timemachine/merged
systemctl status timemachine
mount
machinectl list
systemctl status timemachine
machinectl list
machinectl login timemachine
nsenter -t $(machinectl show timemachine -p Leader --value) -m -u -i -n -p login -f root
nsenter --target $(machinectl show timemachine -p Leader --value) --mount --net --uts --ipc --pid /bin/sh
nsenter -t $(pgrep -f "systemd-nspawn.*-M timemachine" | xargs -I {} pgrep -P {} -f "/lib/systemd/systemd") -m -u -i -n -p login -f root
nsenter -t $(cat /sys/fs/cgroup/system.slice/timemachine.service/cgroup.procs | head -n 2 | tail -n 1) -m -u -i -n -p login -f root
pgrep -f "systemd-nspawn.*-M timemachine"
cat /sys/fs/cgroup/system.slice/timemachine.service/cgroup.procs | tail -n 1
systemctl show timemachine.service -p MainPID --value
systemctl status timamachine
systemctl status timemachine
machinectl list
systemctl staке timemachine
systemctl start timemachine
systemctl status timemachine
machinectl list
machinectl shell root@timemachine
machinectl list
systemctl status timemachine
machinectl list
machinectl shell root@timemachine
machinectl show timemachine -p Leader --value
machinectl list
systemctl start timemachine
machinectl list
machinectl show timemachine -p Leader --value
machinectl list
nsenter --target $(machinectl show timemachine -p Leader --value) --mount --net --uts --ipc --pid /bin/sh
machinectl list
systemctl start timemachine
nsenter --target $(machinectl show timemachine -p Leader --value) --mount --net --uts --ipc --pid /bin/sh
machinectl list
nsenter --target $(machinectl show timemachine -p Leader --value) --mount --net --uts --ipc --pid /bin/sh
machinectl list
systemctl status timemachine
mc
systemctl status timamachine
systemctl status timemachine
systemctl status timemachine
systemctl status timemachine
machinectl list
machinectl list
systemctl status timemachine
journalctl -u timemachine.service --no-pager -n 100
systemctl status timemachine
machinectl list
machinectl list
journalctl -u timemachine.service --no-pager -n 100
machinectl list
journalctl -u timemachine.service --no-pager -n 100
journalctl -u timemachine.service --no-pager -n 100
machinectl list
systemctl status timemachine
systemctl status timemachine
machinectl list
machinectl show timemachine -p Leader --value
machinectl list
systemctl status timemachine
systemctl stop timemachine
systemctl status timemachine
machinectl list
machinectl list
machinectl list
ping 8.8.8.8
apt search ftp
machinectl list
systemctl status timemachine
mc
mount -t iso9660 extended-1.7.6.EXT2.1-15.10.2024_20.28.iso /media/cdrom
umount /media/cdrom
mount -t iso9660 base-1.7.6.15-15.11.24_17.20.iso /media/cdrom
umount /media/cdrom
nsenter --target $(machinectl show timemachine -p Leader --value) --mount --net --uts --ipc --pid /bin/sh
cd /
cat /etc/faketime
systemctl stop timemachine
cat /etc/faketime
systemctl stop timemachine
cat /etc/faketime
systemctl status timemachine
cat /etc/faketime
systemctl stop timemachine
cat /etc/faketime
systemctl status timemachine
cat /etc/faketime
systemctl status timemachine
cat /etc/faketime
systemctl stop timemachine
cat /etc/faketime
systemctl status timemachine
cat /etc/faketime
systemctl stop timemachine
cat /etc/faketime
systemctl status timemachine
systemctl start timemachine
systemctl status timemachine
systemctl start timemachine
systemctl status timemachine
cat /etc/faketime
systemctl restart timemachine
cat /etc/faketime
echo "1768434000" | sudo tee /etc/faketime
systemctl status timemachine
cat /etc/faketime
systemctl status timemachine
systemctl restart timemachine
systemctl status timemachine
systemctl start timemachine
systemctl status timemachine
systemctl restart timemachine
systemctl status timemachine
systemctl restart timemachine
systemctl status timemachine
systemctl restart timemachine
systemctl status timemachine
systemctl restart timemachine
systemctl status timemachine
systemctl restart timemachine
systemctl status timemachine
machinectl list
systemctl restart timemachine
systemctl status timemachine
mc
ps ax
ps ax
apt install chrony
apt install dialog
